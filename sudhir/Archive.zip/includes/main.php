<section id="collection">
        <div class="collections container">
            <div class="content">
                <img src="https://i.postimg.cc/Xqmwr12c/clothing.webp" alt="img" />
                <div class="img-content">
                    <p>Clothing Collections</p>
                    <button><a href="#sellers">SHOP NOW</a></button>
                </div>
            </div>
            <div class="content2">
                <img src="https://i.postimg.cc/8CmBZH5N/shoes.webp" alt="img" />
                <div class="img-content2">
                    <p>Shoes Spring</p>
                    <button><a href="#sellers">SHOP NOW</a></button>
                </div>
            </div>
            <div class="content3">
                <img src="https://i.postimg.cc/MHv7KJYp/access.webp" alt="img" />
                <div class="img-content3">
                    <p>Accessories</p>
                    <button><a href="#sellers">SHOP NOW</a></button>
                </div>
            </div>
        </div>
    </section>